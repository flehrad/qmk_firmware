# The default keymaps for GNGKB75
