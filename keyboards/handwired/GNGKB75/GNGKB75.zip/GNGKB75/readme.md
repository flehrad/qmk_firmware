#GNGKB75

Layout by goodnewsgeorge

HHKB Inspired 75% keyboard

Keyboard Maintainer: [Flehrad](https://github.com/flehrad)  
Hardware Supported: GNGKB75 PCB, Elite-C MCU, MX switches  
Hardware Availability: The Board Podcast Slack, https://github.com/flehrad/GNGKB75

Make example for this keyboard (after setting up your build environment):

    make GNGKB75:default

See the [build environment setup](https://docs.qmk.fm/#/getting_started_build_tools) and the [make instructions](https://docs.qmk.fm/#/getting_started_make_guide) for more information. Brand new to QMK? Start with our [Complete Newbs Guide](https://docs.qmk.fm/#/newbs).
